%%%%%%%% SIMULATION %%%%%%%%%%%%

clear;
clc; 
close all;

%% Generating a random matrix sigma_x

n = 128;
set_of_vectors = 10000*rand(128,128);
sigma_x = cov(set_of_vectors);
[U,lambda] = eig(sigma_x);

% Generating X from the sigma_x matrix with zero mean
mu = zeros(1,128);
x = mvnrnd(mu,sigma_x, 10);

% Sensing matrix
m = [40, 50, 64, 80, 100, 120];

% For the case of alpha  = 0
lambda_new = eye(n);
sigma_x_0 = (U'*lambda_new)*U;

avgrmse = zeros(length(m),1);
for i = 1:length(m)
    disp(["Estimating with m = ", m(i)])
    rmse = 0;
    for j = 1:size(x,1)
        % Generating the compressive mesurements for each x
        phi = normrnd(0,1/m(i),m(i),n);
        y = phi*x(j,:)';
        sigma = 0.01*mean(abs(y));
        y = y + (sigma.^(2)).*randn(m(i),1);

        % reconstructing X using the MAP estimate formula
        x_estimated = (((phi'*phi)/(2.*sigma.*sigma) + sigma_x_0\eye(n))\phi')*y;

        % Computing the RMSE of the estimated value
        rmse = rmse + (x(j,:)' - x_estimated)'*(x(j,:)' - x_estimated);
    end
    avgrmse(i) = rmse;
end

figure(1)
plot(m, avgrmse)
xlabel('m')
ylabel('Average RMSE')
title('Plot of RMSE vs m for \alpha = 0')

%%
disp("For $\alpha$ = 3")
% For the case of alpha  = 3
weight_vector = zeros(n,1);
for i=1:n
    weight_vector(i) = i^(-3);
end

lambda_new = diag(weight_vector);
sigma_x_3 = (U'*lambda_new)*U;
avgrmse = zeros(length(m),1);

for i = 1:length(m)
    disp(["Estimating with m = ", m(i)])
    rmse = 0;
    for j = 1:size(x,1)
        % Generating the compressive mesurements for each x
        phi = normrnd(0,1/m(i),m(i),n);
        y = phi*x(j,:)';
        sigma = 0.01*mean(abs(y));
        y = y + (sigma.^(2)).*randn(m(i),1);

        % reconstructing X using the MAP estimate formula
        x_estimated = (((phi'*phi)/(2.*sigma.*sigma) + sigma_x_3\eye(n))\phi')*y;

        % Computing the RMSE of the estimated value
        rmse = rmse + (x(j,:)' - x_estimated)'*(x(j,:)' - x_estimated);
    end
    avgrmse(i) = rmse;
end

figure(2)
plot(m, avgrmse)
xlabel('m')
ylabel('Average RMSE')
title('Plot of RMSE vs m for \alpha = 3')