%% Question 6 
clear
close all

%% (a)
% gray_image = get_frames_images('/MATLAB Drive/HW1/cars.avi', 120, 240,3);
gray_image = get_frames_images('/MATLAB Drive/HW1/cars.avi', 120, 240,7);
for i=4:7
    figure(i), imshow(uint8(gray_image(:,:,i)))
end
% figure(1), imshow(uint8(gray_image(:,:,1)))
% figure(2), imshow(uint8(gray_image(:,:,2)))
% figure(3), imshow(uint8(gray_image(:,:,3)))

%% (b)
[coded_snapshot, binary_code_mat] = get_coded_snapshot(gray_image, 2);

[val, in] = max(coded_snapshot);
figure(4), imshow(uint8(255.*coded_snapshot./val))
title('Coded Snapshot for T = 3')

%% (c)

%% (d)

%% (e)

% Final reconstructed image after averaging over overlapping pixels
reconstructed_image = OMP(coded_snapshot, binary_code_mat, 8, 9*64*4, 3);

% Displaying the reconstructed images
for k=5:5+3-1
    figure(k), imshow(uint8(reconstructed_image(:,:,k-4)))
%     title(["Reconstruction of frame (for T=3) : ",k-4])
end

average_error = RMSE(reconstructed_image, gray_image);
disp(["Average RMSE for T = 3", average_error]) % Average RMSE : 28.2325

%% (f)

% Reconstruction for T= 5

gray_image = get_frames_images('/MATLAB Drive/HW1/cars.avi', 120, 240, 5);
[coded_snapshot, binary_code_mat] = get_coded_snapshot(gray_image, 2);


[val, in] = max(coded_snapshot);
figure(8), imshow(uint8(255.*coded_snapshot./val))
title('Coded Snapshot for T = 5')

% Reconstructed images for T = 5
reconstructed_image_5 = OMP(coded_snapshot, binary_code_mat, 8, 9*64, 5);

% Displaying images in 
for k=9:9+5-1
    figure(k), imshow(uint8(reconstructed_image_5(:,:,k-8)))
%     title(["Reconstruction of frame (for T=5) : ",k-8])
end

average_error = RMSE(reconstructed_image_5, gray_image);
disp(["Average RMSE for T=",5,":",average_error])

%% Reconstruction for T=7

gray_image = get_frames_images('/MATLAB Drive/HW1/cars.avi', 120, 240, 7);
[coded_snapshot, binary_code_mat] = get_coded_snapshot(gray_image, 2);

[val, in] = max(coded_snapshot);
figure(14), imshow(uint8(255.*coded_snapshot./val))
title('Coded Snapshot for T = 7')

% Reconstructed images for T = 7
reconstructed_image_7 = OMP(coded_snapshot, binary_code_mat, 8, 9*64, 7);

% Displaying images for T = 7
for k=15:15+7-1
    figure(k), imshow(uint8(reconstructed_image_7(:,:,k-14)))
%     title(["Reconstruction of frame (for T=7) : ",k-14])
end

% Reconstruction Error : (Relative Mean Squared Error = Mean Squared Error)
average_error = RMSE(reconstructed_image_7, gray_image);
disp(["Average RMSE for T=",7,":",average_error])

%% (g)

figure(10),imshow(uint8(reconstructed_image_7(:,:,1)))
%% (f) Experiment with 'flame.avi'
close all

% Working on a 120x240 section of the video in the corner
gray_image = get_frames_images('/MATLAB Drive/HW1/flame.avi', 120, 240, 5);
[coded_snapshot, binary_code_mat] = get_coded_snapshot(gray_image, 2);

for i=1:5
    figure(i), imshow(uint8(gray_image(:,:,i)))
end

%%

[val, in] = max(coded_snapshot);
figure(22), imshow(uint8(255.*coded_snapshot./val))
title('Coded Snapshot for T=5 in flames.avi')

reconstructed_image_flame = OMP(coded_snapshot, binary_code_mat, 8, 9*64, 5);

%%
% Displaying images for T=5 with 'flames.avi'
for k=23:23+5-1
    figure(k), imshow(uint8(reconstructed_image_flame(:,:,k-22)))
%     title(["Reconstruction of frame : ",k-22])
end

% Reconstruction Error : (Relative Mean Squared Error = Mean Squared Error)
average_error = RMSE(reconstructed_image_flame, gray_image);
disp(["Average RMSE for T=",5,"in flames.avi :",average_error])

%% Functions 

function reconstructed_image = OMP(coded_snapshot, binary_code_mat, patchsize, epsilon, T)
    [H,W] = size(coded_snapshot);
    % Error Term (epsilon) : defined as 9*m*(sigma^(2))
    % Initializing the recon    econstructed = zeros(H,W,T);
    % Counts, to be used during reconstruction
    counts = zeros(H,W,T);
    reconstructed = zeros(H,W,T);
    for i= 1:H-patchsize
        for j=1:W-patchsize
            % Binary Code Patch
            coded_patch = coded_snapshot(i:i+patchsize-1, j:j+patchsize-1);
            % Coded Image
            patch_code = binary_code_mat(i:i+patchsize-1,j:j+patchsize-1,:);
            y = reshape(coded_patch,patchsize*patchsize, 1);
            % 2D-DCT Matrix
            dct_matrix_2d = kron(dctmtx(patchsize),dctmtx(patchsize));
            % Concatenating Diagonally for all three frames
            psi = kron(eye(T), dct_matrix_2d);
            phi = [];
            for t=1:T
                  temp = diag(reshape(patch_code(:,:,t),patchsize*patchsize,1));
                  phi = [phi temp];
            end
            % Implementing OMP
            A = phi*psi';
            r = y;
            T_mat = [];
            p = 0;
            theta = zeros(size(A,2),1);
            while dot(r,r) > epsilon && p < 64
%                 disp(["Step ",p," Loss : ", dot(r,r)])
                [~,index] = max(abs(r.' * normc(A)));
                T_mat = [T_mat index];
                p = p+1;
                A_T = A(:,T_mat);
                theta(T_mat) = pinv(A_T) * y;
                r = y - A_T*theta(T_mat);
            end
%             disp(["OMP complete for patch : ", i, j]) % checker for the patch
    %         disp(["Terminating iteration : ", p]) % To check if the OMP terminates before p < m
            % Compting 2D-IDCT for all the frames
            idct_image = psi' * theta;
            % Reconstructing the idct image
            for l=1:T
                f = reshape(idct_image((l-1)*patchsize*patchsize + 1: l*patchsize*patchsize), patchsize, patchsize);
                reconstructed(i:i+7,j:j+7,l) = reconstructed(i:i+7,j:j+7,l) + f;
                counts(i:i+7,j:j+7,l) = counts(i:i+7,j:j+7,l) + ones(patchsize, patchsize);
            end
%             disp("Patch Reconstructed")
        end
    end

    reconstructed_image = reconstructed./counts;

end


function gray_image = get_frames_images(videopath, H,W,T)
    video = mmread(videopath, 1:T); % Reading the first three frames
    frames = video.frames;
    
    % Dimensions of video frame
    [im_H, im_W, ~] = size(frames(1).cdata);
    
    % Taking [120,240], converting RGB to grayscale image
    gray_image = zeros(H,W,T);
    for i=1:T
        gray_image(:,:,i) = rgb2gray(frames(i).cdata(im_H-H:im_H-1, im_W-W:im_W-1,:));
    end
end

function [coded_snapshot, binary_code_mat] = get_coded_snapshot(image_array, sigma)
    [H,W,T] = size(image_array);
    % Binary Coded Matrix
    binary_code_mat = randi([0,1],H,W,T);
    % Getting the coded patches
    patches_coded = zeros(H,W,T);
    for i=1:T
        patches_coded(:,:,i) = image_array(:,:,i).*binary_code_mat(:,:,i);
    end
    % Summing up coded patches to get coded snapshot
    coded_snapshot = sum(patches_coded, 3);
    % Adding gaussian noise of zero mean and standard deviation 2
    coded_snapshot = coded_snapshot + sigma*randn(H,W);
end

function avg_error = RMSE(reconstructed_image, original_image)
    avg_error = 0;
    N = size(reconstructed_image,3);
    for t=1:N
        [H,W] = size(reconstructed_image(:,:,t));
        error = abs(uint8(reconstructed_image(:,:,t)) - uint8(original_image(:,:,t)));
        er_mse = sum(sum(error.*error))/(H*W);  
        avg_error = avg_error + er_mse;
    end
    avg_error = avg_error/N;
end


